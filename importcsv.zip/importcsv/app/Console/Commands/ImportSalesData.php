<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class ImportSalesData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:salesdata';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'import sales data from csv files';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */

    public function handle(){
        echo 'File reading...'; echo PHP_EOL;
        // Count them, then grab them in chunks of 10.
        $filename = base_path("resources/sales_import/db.csv");
        

        $rows = $this->csv_row_count($filename);
        echo 'Total rows:'.$rows; echo PHP_EOL;

        echo 'Importing Data...'; echo PHP_EOL;

        $items_per_run = 5000; 
        for ($i=0; $i <= $rows; $i = $i+$items_per_run+1) {
            $data =[];  $import_data =array();
            $chunk = $this->csv_slice($filename, $i, $items_per_run);
            foreach ($chunk as $item) {  //echo 'Chunks==<pre>';print_r($chunk); die;
                //echo "$i - item category = " .  $item->CurrentURL . "\n"; //Note CurrentURL is a case sensitive  

                $import_data['country']  = $item->country;
                $import_data['sales']  = $item->sales;
                $import_data['year']  = $item->year;               

                $data[] = $import_data; 

            }   
            //echo 'Chunks==<pre>';print_r($data);die;
            
            $collection = collect($data);   //turn data into collection
            $chunks = $collection->chunk(100); //chunk into smaller pieces
            $chunks->toArray(); //convert chunk to array

            //loop through chunks:
            foreach($chunks as $chunk)
            {                          
                \DB::table('sales')->insert($chunk->toArray());
            } 
            $data=[];
            $import_data =array();

        }
        echo 'Data import completed'; echo PHP_EOL;

    }

    private function csv_row_count($filename) {
        ini_set('auto_detect_line_endings', TRUE);
        $row_count = 0;
        if (($handle = fopen($filename, "r")) !== FALSE) {
        while (($row_data = fgetcsv($handle, 2000, ",")) !== FALSE) {
            $row_count++;
        }
        fclose($handle);
        // Exclude the headings.
        $row_count--;
        return $row_count;
        }
    }

    // exclude the headings of CSV file
    private function csv_slice($filename, $start, $desired_count) {
        $row = 0;
        $count = 0;
        $rows = array();
        if (($handle = fopen($filename, "r")) === FALSE) {
          return FALSE;
        }
        while (($row_data = fgetcsv($handle, 2000, ",")) !== FALSE) {
          // Grab headings.
          if ($row == 0) {
            $headings = $row_data;
            $row++;
            continue;
          }
      
          // Not there yet.
          if ($row++ < $start) {
            continue;
          }
      
          $rows[] = (object) array_combine($headings, $row_data);
          $count++;
          if ($count == $desired_count) {
            return $rows;
          }
        }
        return $rows;
    }






/*    public function handle()
    {
        //set the path for the csv files
        $path = base_path("resources/sales_import/*.csv"); 
        
        //run 2 loops at a time 
        foreach (array_slice(glob($path),0,2) as $file) {
            
            //read the data into an array
            $data = array_map('str_getcsv', file($file));

            //loop over the data
            foreach($data as $row) {

                //insert the record or update if the email already exists
                //Contact::updateOrCreate([
                //    'email' => $row[6],
                //], ['email' => $row[6]]); 

                \DB::table('sales')
                    ->updateOrInsert(
                        ['country' =>  $row[1], 'sales' => $row[2], 'year' => $row[3], ],
                        ['country' => $row[1], 'year' => $row[3]]
                    );


            }

            //delete the file
            unlink($file);
        }

    }  */
}
