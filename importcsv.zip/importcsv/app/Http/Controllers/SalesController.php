<?php

namespace App\Http\Controllers;
use App\Jobs\ProcessCSVImport;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\SalesModel;

use Session;
use Validator;
use Response;


class SalesController extends Controller
{
    public function __construct() {       
        $this->sales_model = new SalesModel();
    }

    function startUpload(Request $request){ 
        Session::flash('status', 'Queued for csv import.');
        //ProcessCSVImport::dispatch();
        //ProcessCSVImport::dispatchNow();
        ProcessCSVImport::dispatch()->delay(now()->addMinutes(1));

        return redirect()->back();
    }

    public function list()
    {  
        return view('list');
    }

     // List
    public function sales_list(Request $request)
    {
        ## Read value
        $draw = $_POST['draw'];
        $row = $_POST['start'];
        $rowperpage = $_POST['length']; // Rows display per page
        $columnIndex = $_POST['order'][0]['column']; // Column index
        $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
        $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
        $searchValue = $_POST['search']['value']; // Search value
            
            $search_where = array();

            $data['filter'] = '';
            $data['f_year'] = '';
            $data['t_year'] = '';
            $data['country'] = '';
            $raw_where = '';
            

        if($request->input('country') && $request->input('country')!=''){
            $country = trim($request->input('country'));
            $search_where[] = array('sales.country','LIKE', '%'.$country.'%');            
        }         
        if($request->input('f_year') && $request->input('f_year')!=''){
            $f_year = trim($request->input('f_year'));           
            $search_where[] = array('sales.year','>=',$f_year);             
        } 
        if($request->input('t_year') && $request->input('t_year')!=''){
            $t_year = trim($request->input('t_year')); 
            $search_where[] = array('sales.year','<=',$t_year); 
        }   
        if($searchValue != ''){            
            $raw_where .= " (sales.country LIKE '%".$searchValue."%' OR sales.year LIKE '%".$searchValue."%' OR sales.sales LIKE '%".$searchValue."%')"; 
        }   
            
        $totalRecordwithFilter = $this->sales_model->total_row_count($table = "sales", $select = array(), $where = $search_where, $join = array(), $left = array(), $right = array(), $order = array(), $group = "", $limit = array(), $raw = "", $paging = "", $or_where = array(), $having=array(), $raw_where, $where_in=array());

        $data = $this->sales_model->get_all($table = "sales", $select = array('sales.country','sales.sales','sales.year'), $where = $search_where, $join = array(), $left = array(), $right = array(), $order = array(), $group = "", $limit = array($row=>$rowperpage), $raw = "", $paging = "", $or_where = array(), $having=array(), $raw_where, $where_in=array());
        
        if(empty($data)){
            $data = array();
        }

        ## Response
        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => 0,
            "iTotalDisplayRecords" => $totalRecordwithFilter,
            "aaData" => $data,
            'last_page' =>'',
        );

        echo json_encode($response);

            
    }


    public function processImport()
    {  
        request()->validate([
            'csv_file' => 'required|mimes:csv,txt'
        ]);

        //get CSV file from form 
        $filePath = request()->file('csv_file')->getRealPath();

        //CSV file into array
        $csvFile = file($filePath);

        //remove header(columns) of CSV file
        $csvData = array_slice($csvFile, 1);

        //looping through CSV file and split every 1000 rows
        $parts = (array_chunk($csvData, 1000));
        $i = 1;

        $destinationPath = './resources/sales_import/';       
        if(!file_exists($destinationPath))
        {
            mkdir($destinationPath, 0777, true);
        }
                            
        foreach($parts as $line) {
            // append counter value to make file name unique
            $filename = base_path('resources/sales_import/'.date('y-m-d-H-i-s').$i.'.csv');
            file_put_contents($filename, $line);
            $i++;
        }
        \Artisan::call('import:salesdata'); 
        session()->flash('status', 'queued for CSV data importing'); 

        return redirect("/");  

    }


}
