<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Redis;

class ProcessCSVImport implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 1;

    /**
     * Execute the job.
     *
     * @return void
     */
    
    public function handle1(){
        file_put_contents('test.txt', "=======================".date('Y-m-d H:i:s')."=======================\n", FILE_APPEND);
    }


    public function handle()
    {
        \Redis::throttle('upload-csv')->allow(1)->every(600)->then(function () {  

            $filename = base_path("resources/sales_import/db.csv");
            $rows = $this->csv_row_count($filename); 
            
            dump('Total rows: ', $rows);
            dump('Importing Data...');            

            $items_per_run = 10000; 
            for ($i=0; $i <= $rows; $i = $i+$items_per_run+1) {
                $data =[];  $import_data =array();
                $chunk = $this->csv_slice($filename, $i, $items_per_run);
                foreach ($chunk as $item) {  //echo 'Chunks==<pre>';print_r($chunk); die;
                    //echo "$i - item category = " .  $item->CurrentURL . "\n"; //Note CurrentURL is a case sensitive  

                    $import_data['country']  = $item->country;
                    $import_data['sales']  = $item->sales;
                    $import_data['year']  = $item->year;               

                    $data[] = $import_data; 

                }   
                //echo 'Chunks==<pre>';print_r($data);die;
                
                $collection = collect($data);   //turn data into collection
                $chunks = $collection->chunk(100); //chunk into smaller pieces
                $chunks->toArray(); //convert chunk to array

                //loop through chunks:
                foreach($chunks as $chunk)
                {                          
                    \DB::table('sales')->insert($chunk->toArray());
                } 
                $data=[];
                $import_data =array();

            }
           
            dump('Data import completed'); 
            @unlink($filename);
            dump('CSV file deleted'); 
            dump('Data import completed'); 
            
        }, function () {
            // Could not obtain lock...
        
            return $this->release(10);
        });
    }

    private function csv_row_count($filename) {
        ini_set('auto_detect_line_endings', TRUE);
        $row_count = 0;
        if (($handle = fopen($filename, "r")) !== FALSE) {
        while (($row_data = fgetcsv($handle, 2000, ",")) !== FALSE) {
            $row_count++;
        }
        fclose($handle);
        // Exclude the headings.
        $row_count--;
        return $row_count;
        }
    }

    // exclude the headings of CSV file
    private function csv_slice($filename, $start, $desired_count) {
        $row = 0;
        $count = 0;
        $rows = array();
        if (($handle = fopen($filename, "r")) === FALSE) {
          return FALSE;
        }
        while (($row_data = fgetcsv($handle, 2000, ",")) !== FALSE) {
          // Grab headings.
          if ($row == 0) {
            $headings = $row_data;
            $row++;
            continue;
          }
      
          // Not there yet.
          if ($row++ < $start) {
            continue;
          }
      
          $rows[] = (object) array_combine($headings, $row_data);
          $count++;
          if ($count == $desired_count) {
            return $rows;
          }
        }
        return $rows;
    }

}
