<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use DateTime;
use DateTimeZone;


class SalesModel extends Model {

    public function total_row_count($table, $select = array(), $where = array(), $join = array(), $left = array(), $right = array(), $order = array(), $group = "", $limit = array(), $raw = "", $paging = "", $or_where = "", $having = array(), $raw_where = "", $where_in = array()) {
        $base = DB::table($table);
       
        $txt = "count(*) as count";
        if($raw != ""){
            $txt = $txt.",".$raw;
        }
        $base->select(DB::raw($txt));
        
        if (!empty($where)) {
            foreach ($where as $wh) {
                $base->where($wh[0], $wh[1], $wh[2]);
            }
        }
        if (!empty($where_in)) {
            foreach ($where_in as $key=>$val) {
                if (!empty($val)) {
                    $base->whereIn($key, $val);
                }
            }
        }
        if (!empty($or_where)) {
            foreach ($or_where as $owh) {
                $base->orWhere($owh[0], $owh[1], $owh[2]);
            }
        }        
        // left join with where condition on joining table
        if (!empty($left)) {
            foreach ($left as $lf) {               
               $base->leftJoin($lf[0], function($join) use ($lf){
                    $join->on($lf[1], $lf[2] , $lf[3]);
                    if(!empty($lf[4]) && is_array($lf[4])){
                        $left_where = $lf[4];
                        $join->where($left_where[0],$left_where[1],$left_where[2]);
                    }                    
               });
            }
        }
        if (!empty($right)) {
            foreach ($right as $rt) {
                $base->rightjoin($rt[0], $rt[1], $rt[2], $rt[3]);
            }
        }
        if (!empty($join)) {
            foreach ($join as $jn) {
                $base->join($jn[0], $jn[1], $jn[2], $jn[3]);
            }
        }
        if ($group != "") {
            $base->groupby($group);
        }
        if (!empty($having)) {
            foreach ($having as $hv) {
                $base->having($hv[0], $hv[1], $hv[2]);
            }
        }
       
        if ($raw_where != "") {

            $base->whereRaw(DB::raw($raw_where));
        }

        if ($paging != "") {
            //
        } else {

            $data = $base->get();
        }
        if (count($data) > 0) {             
            return $data[0]->count;
        } else {
            return 0;
        }
        
    }
    
    function get_all($table, $select = array(), $where = array(), $join = array(), $left = array(), $right = array(), $order = array(), $group = "", $limit = array(), $raw = "", $paging = "", $or_where = "", $having = array(), $raw_where = "", $where_in = array()) {
        $base = DB::table($table);
        if (!empty($select)) {
            $base->select($select);
        } else {
            $base->select('*');
        }
        if ($raw != "") {
            $base->select(DB::raw($raw));
        }
        if (!empty($where)) {
            foreach ($where as $wh) {
                $base->where($wh[0], $wh[1], $wh[2]);
            }
        }
        if (!empty($where_in)) {
            foreach ($where_in as $key=>$val) {
                if (!empty($val)) {
                    $base->whereIn($key, $val);
                }
            }
        }
        if (!empty($or_where)) {
            foreach ($or_where as $owh) {
                $base->orWhere($owh[0], $owh[1], $owh[2]);
            }
        }
        if (!empty($order)) {
            foreach ($order as $od) {
                foreach ($od as $key => $val) {
                    $base->orderby($key, $val);
                }
            }
        }
        /*if (!empty($left)) {
            foreach ($left as $lf) {
                $base->leftJoin($lf[0], $lf[1], $lf[2], $lf[3]);
            }
        } */
        // left join with where condition on joining table
        if (!empty($left)) {
            foreach ($left as $lf) {               
               $base->leftJoin($lf[0], function($join) use ($lf){
                    $join->on($lf[1], $lf[2] , $lf[3]);

                    // if where condition with left join
                    if(!empty($lf[4]) && is_array($lf[4])){
                        $left_where = $lf[4];
                        $join->where($left_where[0],$left_where[1],$left_where[2]);
                    }   
                    // if multiple ON condition
                    if(!empty($lf[5]) && is_array($lf[5])){
                        $second_on = $lf[5];
                        $join->on($second_on[0], $second_on[1] , $second_on[2]);
                    }                 
               });
            }
        }

        if (!empty($right)) {
            foreach ($right as $rt) {
                $base->rightjoin($rt[0], $rt[1], $rt[2], $rt[3]);
            }
        }
        if (!empty($join)) {
            foreach ($join as $jn) {
                $base->join($jn[0], $jn[1], $jn[2], $jn[3]);
            }
        }
        if ($group != "") {
            //$base->groupby($group);
            $groups = explode(',', $group);
            foreach($groups as $group){
                $base->groupby($group);
            }
        }
        if (!empty($having)) {
            foreach ($having as $hv) {
                $base->having($hv[0], $hv[1], $hv[2]);
            }
        }
        // return $having;
        //return $raw;
        if (!empty($limit)) {
            foreach ($limit as $of => $lim) {
                $base->offset($of);
                $base->limit($lim);
            }
        }

        if ($raw_where != "") {

            $base->whereRaw(DB::raw($raw_where));
        }

        if ($paging != "") {
            $data = $base->paginate($paging);
        } else {

            $data = $base->get();
        }
        if (count($data) > 0) {
            return $data;
        } else {
            return false;
        }
        //return $data=array('head'=>"This is laravel",'body'=>"Welcome to my laravel application");
    }


    
}

