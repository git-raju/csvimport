<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/dataTables.bootstrap4.min.css')); ?>">

        <!-- Styles -->
        <style>            
        body {
        min-height: 100vh;

        background-color: #FFE53B;
        background-image: linear-gradient(147deg, #FFE53B 0%, #FF2525 100%);
        }
        .dataTables_info{display:none;}
        </style>
    </head>
    <body>
        <div class="container">
            <header class="text-center text-white">
              <h1 class="display-4">Sales List</h1>             
            </header>
            <div class="row">
                <div class="col-lg-3 card-body p-5 bg-white rounded">
                    <h4>Filter Options</h4>                    
                    <form class="login-form" action="" method="POST" enctype="application/x-www-form-urlencoded">
                        <?php echo e(csrf_field()); ?>

                        <label for="filter">Choose a filter</label>
                        <select class="form-control margin-bg" id="filter" name="filter" required="">  
                                <option value="">Select Option</option>                          
                                <option value="1">Sales by year</option>                           
                                <option value="2">Sales by country</option>                            
                                <option value="3">Sales by year &amp; country</option>                            
                                <option value="4">Country-wise sales by year</option>                            
                                <option value="5">Year-wise sales by country</option>                            
                        </select>
                        <div class="w-100" id="year_filter" style="display: block;">
                            <label for="f_year">From year</label>
                            <select class="form-control margin-bg" id="f_year" name="f_year">  
                                <option value="">Select Option</option> 
                                <option value="2010">2010</option>                                        
                                <option value="2011">2011</option>                                       
                                <option value="2012">2012</option>  
                                <option value="2013">2013</option>                                    
                                <option value="2014">2014</option>                                    
                                <option value="2015">2015</option>                                    
                                <option value="2016">2016</option>                                    
                                <option value="2017">2017</option>                                    
                                <option value="2018">2018</option>                                    
                                <option value="2019">2019</option>                                    
                                <option value="2020">2020</option>
                                
                            </select>

                            <label for="f_year">To year</label>
                            <select class="form-control margin-bg" id="t_year" name="t_year">
                                <option value="">Select Option</option> 
                                <option value="2010">2010</option>    
                                                                    
                                        <option value="2011">2011</option>                                       
                                        <option value="2012">2012</option>  
                                        <option value="2013">2013</option>                                    
                                        <option value="2014">2014</option>                                    
                                        <option value="2015">2015</option>                                    
                                        <option value="2016">2016</option>                                    
                                        <option value="2017">2017</option>                                    
                                        <option value="2018">2018</option>                                    
                                        <option value="2019">2019</option>                                    
                                        <option value="2020">2020</option>
                                
                            </select>
                        </div>

                        <div class="w-100" id="country_filter" style="display: none;">
                            <label for="f_year">Country</label>
                            <select class="form-control margin-bg" id="country" name="country">                                
                                <option value="">Select Option</option> 
                                        <option value="Norway">Norway</option>
                                        <option value="Ethiopia">Ethiopia</option>                                    
                                        <option value="Malaysia">Malaysia</option>  
                            </select>
                        </div>

                        <button class="btn btn-light text-white btn-block" style="background-color: #a6c !important;margin-top: 10px;" type="submit" id="submit_filter">Search</button>
                    </form>
                  <form class="login-formwew" action="<?php echo e(route('start.import')); ?>" method="POST" enctype="application/x-www-form-urlencoded">
                      <?php echo e(csrf_field()); ?>

                      <button class="btn btn-light text-white btn-block" style="background-color: #bd7496 !important;margin-top: 10px;" type="submit" id="">Import CSV Data</button>
                      <?php if(Session::has('status')): ?>
                        <p class="alert alert-info"><?php echo e(Session::get('status')); ?></p>
                      <?php endif; ?>

                    </form>

                </div>
              <div class="col-lg-9">
                <div class="card rounded shadow border-0">
                  <div class="card-body p-5 bg-white rounded">
                    <div class="table-responsive">
                      <table id="example" style="width:100%" class="table table-striped table-bordered">
                        <thead>
                          <tr>
                            <th>County</th>
                            <th>Year</th>
                            <th>Sales</th>
                           
                          </tr>
                        </thead>
                        <tbody>
                                                                         
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
<!-- jQuery 3 -->
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/dataTables.bootstrap4.min.js')); ?>"></script>



<script>
    function shutterOptions(e){
        let option = Number(e.target.value)
        domAction(option)
    }

    function domAction(option){
        if(option===1 || option===5){
            document.getElementById('year_filter').style.display = 'block';
            document.getElementById('country_filter').style.display = 'none';
        }
        else if(option===2 || option===4){
            document.getElementById('year_filter').style.display = 'none';
            document.getElementById('country_filter').style.display = 'block';
        }
        else if(option===3){
            document.getElementById('year_filter').style.display = 'block';
            document.getElementById('country_filter').style.display = 'block';
        }
    }


$(document).ready(function() {

    // filter shuttering
    filter = document.getElementById('filter');
    if(filter.addEventListener)
        filter.addEventListener('change', shutterOptions, true);
    else
        filter.attachEvent('onchange', shutterOptions);

    // onload domAction
    domAction(Number(filter.value));

//=========== Datatable =============
var CSRF_TOKEN = $('input[name="_token"]').val();

$('#example').DataTable({
    //searching: false,
    "processing": true,
    "serverSide": true,
    'serverMethod': 'post',
    "ajax": {
      "url": "<?php echo e(route('list.fetch')); ?>",
      "type": "POST",      
          "data": function ( d ) {
                d._token = CSRF_TOKEN;
                               
            }
    },  
    "drawCallback": function (settings) { 
      var response = settings.json;
                
    },        
    "columns": [				
      { "data": "country" },
      { "data": "sales" },
      { "data": "year" }
    ]
});     

$('button#submit_filter').click( function(e) {  e.preventDefault();
    loadSearchData();
});

  function loadSearchData(){

var CSRF_TOKEN = $('input[name="_token"]').val();
//var startAfter = $("#startAfter").val();

var filter = $('#filter').val(),
    f_year = $('#f_year').val(),
    t_year = $('#t_year').val(),
    country = $('#country').val();   
    
    //alert('F='+filter); alert('F='+f_year);alert('F='+t_year);alert('F='+country); return false;

$('#example').DataTable().destroy();

$('#example').DataTable({
  //searching: false,
  "processing": true,
  "serverSide": true,
  'serverMethod': 'post',
  "ajax": {
    "url": "<?php echo e(route('list.fetch')); ?>",
    "type": "POST",
    //data: postData,
    "data": function ( d ) {
        d._token = CSRF_TOKEN;
        d.filter = filter;
        d.f_year = f_year;
        d.t_year = t_year;
        d.country = country;                
    }
  },    
  "drawCallback": function (settings) { 
    var response = settings.json;
      //$('#startAfter').val(response.startAfter);
      //startAfter = response.startAfter;
  },   
  "columns": [				
        { "data": "country" },
        { "data": "sales" },
        { "data": "year" }
    
  ]
});

}




});

</script>
    </body>
</html>
<?php /**PATH E:\wamp\www\importcsv\resources\views/list.blade.php ENDPATH**/ ?>